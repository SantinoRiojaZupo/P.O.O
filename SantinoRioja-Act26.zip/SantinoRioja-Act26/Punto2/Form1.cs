﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto2
{
    /*2. Permitir el ingreso de dos números en controles de tipo TextBox y mediante
dos controles de tipo RadioButton permitir seleccionar si queremos sumarlos o
restarlos. Al presionar un botón mostrar en el título del Form el resultado de la
operación.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int num1 = 0;
        int num2 = 0;
        int total = 0;

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            num1 = int.Parse(textBox1.Text);
            num2 = int.Parse(textBox2.Text);
            total = num1 - num2;
            Text = total.ToString();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

            num1 = int.Parse(textBox1.Text);
            num2 = int.Parse(textBox2.Text);
            total = num1 + num2;
            Text = total.ToString();
        }
    }
}
