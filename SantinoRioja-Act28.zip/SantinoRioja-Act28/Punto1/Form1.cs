﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto1
{
    /*1. Calculadora de Promedio de Notas
● Consigna: Crear un formulario con tres TextBox para ingresar notas y un Button
&quot;Calcular&quot;. Convertir los valores con int.Parse() o double.Parse() y mostrar en una
Label el promedio. Si la nota es mayor o igual a 6, cambiar el color del texto de la
etiqueta a verde; de lo contrario, a rojo.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            double num1;
            double num2;
            double num3;
            double promedio;
            
            num1 = double.Parse(textBox1.Text);
            num2 = double.Parse(textBox2.Text);
            num3 = double.Parse(textBox3.Text);
            promedio = ((num1 + num2 + num3) / 3);
            if (promedio >= 6) { label1.ForeColor = Color.Green; }
            else { label1.ForeColor = Color.Red; }
            label1.Text = promedio.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
