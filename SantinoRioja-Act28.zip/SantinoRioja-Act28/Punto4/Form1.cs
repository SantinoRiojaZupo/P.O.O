﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto4
{
    /*4. Temporizador de Clics (Investigación: Timer)
● Investigación: Explicar el componente Timer (propiedades Interval, Enabled y
evento Tick) con un breve ejemplo explicativo.
● Consigna: Crear un mini-juego donde un Button cuente cuántos clics realiza el
usuario en 10 segundos. Al finalizar el tiempo mediante el Timer, deshabilitar el
botón (Enabled = false) y mostrar el puntaje acumulado en un MessageBox.Show.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            
            InitializeComponent();
        
        }
        int presionado = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            button1.Enabled = false;
            timer1.Enabled = false;
            MessageBox.Show("Cantidad de click en 10 segundos:"+ presionado);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            presionado++;
        }
    }
}
