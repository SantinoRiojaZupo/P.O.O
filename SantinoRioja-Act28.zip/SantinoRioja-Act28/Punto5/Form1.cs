﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto5
{/*5. Visor Dinámico de Imágenes (Investigación: PictureBox)
● Investigación: Investigar la clase PictureBox y sus propiedades ImageLocation y
SizeMode.
● Consigna: Cargar en un ComboBox tres opciones. Al cambiar la selección mediante
el evento SelectedIndexChanged, mostrar la imagen correspondiente dentro del
PictureBox.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public string tomJerry { get; set; } = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrbZi-UWtvniF8j5kmSs1PGy2Hwonh9t8WiNj6weGG9JPZgDB-CJf6hyI&s=10";
        public string chicha { get; set; } = "https://img.magnific.com/foto-gratis/perro-adorable-mirando-arriba-estudio_23-2149016864.jpg";
        public string chufo { get; set; } = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHbzfTJPgMnlqbA258W_PAn3L0FYnDQ8d7KEAO4qWZEaDWaZux9DysbdfC&s=10";
        private void button1_Click(object sender, EventArgs e)
        {
           
            
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            if (comboBox1.SelectedIndex == 0) {
                pictureBox1.ImageLocation = tomJerry;
            
            }
            if (comboBox1.SelectedIndex == 1)
            {
                pictureBox1.ImageLocation = chicha;

            }
            if (comboBox1.SelectedIndex == 2)
            {
                pictureBox1.ImageLocation = chufo;

            }
        }
    }
}
