﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto5
{/*5. Visor Dinámico de Imágenes (Investigación: PictureBox)
● Investigación: Investigar la clase PictureBox y sus propiedades ImageLocation y
SizeMode.
● Consigna: Cargar en un ComboBox tres opciones. Al cambiar la selección mediante
el evento SelectedIndexChanged, mostrar la imagen correspondiente dentro del
PictureBox.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public string tomJerry { get; set; } = "C:\\Users\\Alumno\\Downloads\\tomJerry.jpg";
        public string chicha { get; set; } = "C:\\Users\\Alumno\\Downloads\\chicha.jpg";
        public string chufo { get; set; } = "C:\\Users\\Alumno\\Downloads\\chufo.jpg";
        private void button1_Click(object sender, EventArgs e)
        {
           
            
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            if (comboBox1.SelectedIndex == 0) {
                pictureBox1.ImageLocation = tomJerry;
            
            }
            if (comboBox1.SelectedIndex == 1)
            {
                pictureBox1.ImageLocation = chicha;

            }
            if (comboBox1.SelectedIndex == 2)
            {
                pictureBox1.ImageLocation = chufo;

            }
        }
    }
}
