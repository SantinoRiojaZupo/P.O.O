﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //3. Se ingresa por teclado un número positivo de uno o dos dígitos (1..99) mostrar un mensaje
            //indicando si el número tiene uno o dos dígitos.(Tener en cuenta que condición debe cumplirse para tener dos dígitos, un número entero)

            int numero;

            Console.WriteLine("Ingrese un numero positivo, entero de 1 o 2 digitos");
            numero = int.Parse(Console.ReadLine());

            if (numero >= 1)
            {
                if (numero<=99) {
                    if (numero < 10)
                    {
                        Console.WriteLine("Tu numero es positivo y tiene 1 digito");
                    }
                    else { Console.WriteLine("Tun numero es positivo y tuene 2 digitos"); }
                }
            }
            Console.ReadKey();
        }
    }
}
