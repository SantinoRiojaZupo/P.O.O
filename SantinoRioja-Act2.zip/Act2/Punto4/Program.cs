﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //4. Se cargan por teclado tres números distintos. Mostrar por pantalla el mayor de ellos.

            int num1, num2, num3;

            Console.WriteLine("Ingresar primer numero:");
            num1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingresar segundo numero:");
            num2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingresar tercer numero:");
            num3 = int.Parse(Console.ReadLine());

            if (num1 > num2) {
                 if (num1 > num3)
                {
                    Console.WriteLine("El mayor es el primer numero");
                } 
            }
            else {
                    if (num2 > num3) {
                        Console.WriteLine("El mayor es el segudo numero"); 
                    }
                    else { Console.WriteLine("El mayor es el tercer numero"); }
                }
            Console.ReadKey();
        }
    }
}
