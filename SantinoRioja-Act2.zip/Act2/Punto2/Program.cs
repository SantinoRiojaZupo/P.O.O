﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //2. Se ingresan seis notas de un alumno, si el promedio es mayor o igual a siete mostrar un mensaje "Promocionado"

            float nota1, nota2, nota3, nota4, nota5, nota6, promedio;
            
            Console.WriteLine("Ingrese la primera nota:");
            nota1= float.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la segunda nota:");
            nota2 = float.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la tercera nota:");
            nota3 = float.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la cuarta nota:");
            nota4 = float.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la quinta nota:");
            nota5 = float.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la sexta nota:");
            nota6 = float.Parse(Console.ReadLine());

            promedio = (nota1 + nota2 + nota3 + nota4 + nota5 + nota6) / 6;

            if (promedio >= 7) {
                Console.WriteLine("Promocionado");
            }
            Console.ReadKey();
        }
    }
}
