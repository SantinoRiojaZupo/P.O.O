﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //1. Realizar un programa que lea por teclado dos números,
            //si el primero es mayor al segundo informar su suma y diferencia,
            //en caso contrario informar el producto y la división del primero respecto al segundo.

            float num1, num2;

            Console.WriteLine("Ingrese el primer numero:");
            num1 = float.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el segundo numero:");
            num2 = float.Parse(Console.ReadLine());

            if (num1 > num2)
            {
                Console.WriteLine("Suma:" + (num1 + num2));
                Console.WriteLine("Diferencia:" + (num1 - num2));
            }
            else {
                Console.WriteLine("Producto: "+ (num1*num2));
                Console.WriteLine("Division"+ (num2/num1));
            }
        }
    }
}
